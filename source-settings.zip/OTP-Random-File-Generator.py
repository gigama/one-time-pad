#William Marcy, PhD, PE
# program purpose
version = '10-20-2023'
print('\n')
print('Author: William Marcy, PhD, PE')
print('This is Public Domain Software')
print('Revised by:----------------')
print('Date of Last Revision:10/20/2023')
print('Version:',version,'\n')


import os #allows use of file size and other operating system methods
          #allows use of urandom which is a crypto secure random number generator



def select_directory() : #returns path & name of the directory selected

    try:

        select_dir = True #gets the while loop started

        new_cwd = 'none' #no directory selected yet

        starting_dir = os.getcwd() #save the current working directory when we enter this function

        while select_dir :

            explore_dir = True   #gets the while loop below started

            #------------------------ begin exploring directories --------------------
            
            while explore_dir: 

                current_cwd = os.getcwd() #save current working directory. This may change
                                          #while this function is used.
                
                print('\nCWD: ',current_cwd)  #just so we know where we are now


                dirs  = [] #list will hold names of sub directories in the CWD, if any
               
                for (dirpath, dirnames, filenames) in os.walk(current_cwd):
                    dirs.extend(dirnames)   #save the sub directory names
                    break                   #we don't need to walk the whole tree
                
                dirs.append("Use Current Working Directory")
                dirs.append('Create A New Sub Directory')

                print('\n--- List of Sub Directories---\n')
            
                for j in range(0,len(dirs))  :  
                    print(j, dirs[j])    
               
                dir_str = input("\nHit Enter to accept current value,'u' to move up a level,'x' to exit operation or # to select: ")
                            
                if dir_str =='' : #we are all finished
                      os.chdir(starting_dir) #reset to the starting directory  
                      return new_cwd          
                                
                if dir_str == 'u' :
                       os.chdir('../') #move up a directory level
                       
                if dir_str =='x' : #we are exiting the operation
                      os.chdir(starting_dir) #reset to the starting directory  
                      return new_cwd   
                       
#                  This should not be implemented since it will allow access to OS directories and files                    
##                if dir_str == 'r':
##                       os.chdir('/') #move to root directory
##                       break 

                dir_no = int(dir_str) #we get here if a number was entered.

                print('\nCWD: ',current_cwd)  #just so we know where we are now

                if dirs[dir_no] == 'Use Current Working Directory':
                    return 'none'

                if dir_no == len(dirs) - 1 :#Create a new directory
                    dir_name = input('Enter a new subdirectory name:')
                    dir_path = current_cwd + '/' + dir_name
                    os.mkdir(dir_path)

                else:
                    new_cwd = current_cwd + '/' + dirs[dir_no]
                    os.chdir(new_cwd) #move to the new directory

    except Exception as Err:
        print('Error in select_directory()')
        print(Err)

def select_file() : #select a file from the current working directory

    try:

        start_cwd = os.getcwd() #save current working directory
        
        print('\nCWD: ',start_cwd)
      
        pause = input("\nEnter to accept current value of CWD or'c' to change CWD: ")

        new_cwd = select_directory()
   
                          
        if new_cwd != 'none':
            os.chdir(new_cwd) #change directories

        current_cwd = os.getcwd() #get current working directory        

        print('\nUsing CWD:',current_cwd)
       

        file_select = True

        file_name = 'none'

        files = [] #list will hold file names of current directory
        file_info = [0]*2 #return information
        
        for (dirpath, dirnames, filenames) in os.walk(current_cwd):
            files.extend(filenames) #save the file names
            break

        files.append('Create A New File') 
        
        
        while file_select :
            print('\nCurrent file name selected: ',file_name)
            print('\n--- Select From List of files ---\n')
           
            for i in range(0,len(files))  :  
                print(i, files[i])    

            file_str = input("\nEnter to accept current file selected, 'x' to exit terminate program or # for Operation:")

            if file_str == '' : #return file name selected
               file_info[0] = current_cwd
               file_info[1] = file_name
               os.chdir(start_cwd) #reset current working directory 
               return file_info 

            if file_str == 'x' : #exiting operation
               file_info[0] = current_cwd
               file_info[1] = 'Program Terminated'
               os.chdir(start_cwd) #reset current working directory 
               return file_info 

                          
            if int(file_str) == len(files)-1 : #this is the last entry which is create a new file
               file_name = input('Enter a new file name:')   
               if file_name=='':
                  file_name='OTP-XB.bin' 
                  print('Using Default:',file_name)
               temp = open(file_name,'w')#create it
               temp.write('New file') 
               temp.close()    

            else :
               file_name = files[int(file_str)] 
            
 

    except Exception as Err:
        print('Error in select_file()')
        print(Err)  
    
def main():

    end_of_program = False

        
    while not end_of_program :

        try:
        
            print('----------------- Select Random Number File To Be Written ---------')
            
            rv = select_file()

            random_number_file = rv[1]
            random_number_directory = rv[0]
            
            if random_number_file =='Program Terminated':
               return('Program Terminated')

            print('Default:OTP-XB.bin\n')
            if random_number_file == 'none' :
                random_number_file = 'OTP-XB.bin'

            random_number_path = random_number_directory + '/' + random_number_file

            print('File:',random_number_file)
            print('Directory:',random_number_directory)
            print('Path:',random_number_path)

            random_file = open(random_number_path,'wb') #this file will receive our random numbers

            number_values = int(input('Number of random values to generate: '))

            print('This could take a while ...')

            n = 0
            
            for i in range(0,number_values):  #generates random bytes of cryptographic quality

                random_byte   = os.urandom(1) #returns one random byte 0-255
                random_number = int.from_bytes(random_byte, byteorder='big') #convert it to an integer 
                
                if i !=0 and i%5000000 == 0 :   #keeping track of progress
                   print(format(i,','),'random numbers generated so far') 

                random_byte   = (random_number).to_bytes(1,byteorder='big',signed = False) #convert the byte to
                                                                                           #an integer 
                random_file.write(random_byte) #write it out to a file

            random_file.close() #house keeping

            file_size = os.path.getsize(random_number_path) #check the size of the file written

            print('\nRandom File Size:', format(file_size,',')) #check on the number of random numberes generated

            pause = input("Paused: Enter to finish, 'g' to generate another: ")

            if pause == '':
                end_of_program = True
                return 'Program ended normally'
        
        except Exception as Err:
            print(Err)


#--------------------- call main() -------------------------
result = main()
print(result)
        
