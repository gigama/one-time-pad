#William Marcy, PhD, PE

import os #lets us use operating system specific functions such as getting file size
import time  #lets us use time functions

version = '10-20-2023'\
          
print('\n')
print('Author: William Marcy, PhD, PE')
print('This is Public Domain Software')
print('Revised by:----------------')
print('Date of Last Revision:10/20/2023')

print('Version:',version,'\n')
print(time.asctime(),'\n')

print('This program uses a known OTP file to search for the cipher key when it is known that a given fragment of text')
print('has been encoded using the OTP to produce a known encrypted file\n')
print('We start with a chosen cipher key (e.g., 0) and use to OTP to encrypt the known fragment of text. We compare the encrypted bytes with the bytes')
print('at the same position in the encrypted file. If they match then we have found the cipher key. When the cypher key has been found')
print('we use the cipher key to decipher the encrypted message. If there is no match we advance the cipher key by one and repeat. Eventually there will')
print('be a match.\n')
print('The time it takes to find the key depends on how fast the computer used is and how big the OTP is. Assume the OTP is 1 GB')
print('and the computer can check 1000 keys/second for a match. On average the match will be found after checking one half of the keys.')
print('This will require on average 500,000 seconds, 8,333 hours or 347 days.\n')

print('To keep values from being written to settings file use command 8 to set all values to default before saving')


def menu(frag_name,frag_dir,cipher_name,cipher_dir, OTP_name, OTP_dir,start_point,settings_file) :

    try:
        
        print('\n   ------------ Command Menu ----------------------- Current Value ----\n')
        print('1  - Get fragment filename                          \t|',frag_name)
        print('   - Dir:',frag_dir)
        print('2  - Get enciphered filename                            \t|',cipher_name)
        print('   - Dir:',cipher_dir)
        print('3  - Get OTP filename                               \t|',OTP_name)
        print('   - Dir:',OTP_dir)
        print('4  - Set starting trial position in OTP             \t|',start_point)
        print('5  - Search for cipher key')
        print('6  - Save current settings ---->',settings_file)
        print('7  - Load saved settings   <----',settings_file)
        print('8  - Reset defaults')
        print('9  - Exit program')
  
      
        command_str = input('\nEnter function number:')
       
        if command_str != '':
            command = int(command_str)
            while command < 1 or command >9 :
                print('Number must be 1 to 9')
                command = int(input('Please re-enter number:'))
        else :
            print('Default is 1')
            command = 1

        return command


    except Exception as Err :
        print('Error in function menu()')
        print(Err)

def save_settings(frag_name, frag_dir, cipher_name, cipher_dir,OTP_name,OTP_dir,start_point,settings_file) :
#                                   0                1                 2                    3                 4                 5                  6        
    try:  
        current_cwd = os.getcwd() #get the current working directory
        #print('Current Working Directory:',current_cwd)
        print('Current Settings File:',settings_file)

        settings = input('Enter a different name for settings file or return to use current value:')

        if settings =='':
            settings = settings_file

        new_settings=settings
        
        settings = open(settings,'w')       
        settings.write(frag_name   +'\n')   #0
        settings.write(frag_dir    +'\n')   #1
        settings.write(cipher_name +'\n')   #2
        settings.write(cipher_dir  +'\n')   #3
        
        settings.write(OTP_name    +'\n')        #4   
        settings.write(OTP_dir     +'\n')            #5
       
        start_point_string = str(start_point)
        settings.write(start_point_string  +'\n')   #6 
        settings.write('\nThe following path string is your current working directory location.\n\n')
        if OTP_name == 'none' :
            settings.write('none\n\n') 
        else:
            settings.write(current_cwd+'\n\n')    #12 This is an aid to editing settings files
        settings.write('Use a text editor such as Notepad to update directory strings\n')
        settings.write('following a relocation of the encipher host directory as needed.\n')
        settings.close()
        
        return new_settings

    except Exception as Err :
         print('Error in function save_settings()')
         print(Err)

def load_settings(settings_file) :

    try:

        print('Current settings file:',settings_file)

        settings = input('Enter a different name for the settings file or return for current value: ')

        if settings == '':
            settings = settings_file

        new_settings = settings

        settings = open(settings,'r')
        rv = [0]*8
        rv[0] = settings.readline() #0 frag_name
        rv[1] = settings.readline() #1 frag_dir
        rv[2] = settings.readline() #2 cipher_name
        rv[3] = settings.readline() #3 cipher_dir
        rv[4] = settings.readline() #4 OTP_name
        rv[5] = settings.readline() #5 OTP_dir
        rv[6] = settings.readline() #6 start point for trial_cipher_key
        rv[7] = new_settings

        settings.close()
        
        return rv

    except Exception as Err:
        print(Err)
        print('Error in function load_settings()')
        return 'none'


def select_directory() : #returns path & name of the directory selected

    try:

        select_dir = True #gets the while loop started

        new_cwd = 'none' #no directory selected yet

        starting_dir = os.getcwd() #save the current working directory when we enter this function

        while select_dir :

            explore_dir = True   #gets the while loop below started

            #------------------------ begin exploring directories --------------------
            
            while explore_dir: 

                current_cwd = os.getcwd() #save current working directory. This may change
                                          #while this function is used.
                
                print('CWD: ',current_cwd)  #just so we know where we are now


                dirs  = [] #list will hold names of sub directories in the CWD, if any
               
                for (dirpath, dirnames, filenames) in os.walk(current_cwd):
                    dirs.extend(dirnames)   #save the sub directory names
                    break                   #we don't need to walk the whole tree
                
                dirs.append("Use Current Working Directory")
              #  dirs.append('Create A New Sub Directory')

                print('\n--- List of Sub Directories---\n')
            
                for j in range(0,len(dirs))  :  
                    print(j, dirs[j])    
               
                dir_str = input("\nEnter to accept current value of CWD,'u' to move up a level, number to select: ")
                            
                if dir_str =='' : #we are all finished
                      os.chdir(starting_dir) #reset to the starting directory  
                      return new_cwd          
                                
                if dir_str == 'u' :
                       os.chdir('../') #move up a directory level 
                       break
                    
#               This should not be implemented since it will provide access to OS files
##                if dir_str == 'r':
##                       os.chdir('/') #move to root directory
##                       break 

                dir_no = int(dir_str) #we get here if a number was entered.

                if dirs[dir_no] == 'Use Current Working Directory':
                    return 'none'

                else:
                    new_cwd = current_cwd + '//' + dirs[dir_no]
                    os.chdir(new_cwd) #move to the new directory

    except Exception as Err:
        print('Error in function select_directory()')
        print(Err)

def select_file(Passed_CWD) : #select a file from the passed current working directory

    try:

        reset_cwd= os.getcwd() #save the current working directory

        if Passed_CWD == 'none':
           start_cwd = os.getcwd() #save the current working directory
        else:
           start_cwd = Passed_CWD #use the one passed in
        
        print('\nCWD: ',start_cwd) #so we know what directory is being used
      
        pause = input("\nEnter to accept the above CWD or 'c' to change CWD: ")

        if pause == 'c':
           start_cwd = select_directory() #find a new directory
           if start_cwd == 'none':
              # No selection was made so continue with the one passed in
              start_cwd = Passed_CWD
           else:
              os.chdir(start_cwd) #change to the selected directory

                        
        current_cwd = os.getcwd() #save current working directory

        print('\nNow Using CWD: ',current_cwd)

              
        file_select = True

        file_name = 'none'

        files = [] #list will hold file names of current directory
        file_info = [0]*2 #return information
        
        for (dirpath, dirnames, filenames) in os.walk(current_cwd):
            files.extend(filenames) #save the file names
            break

        files.append('Create A New File') 
        
        #pause=input('paused')
        
        while file_select :
            print('\nCurrent file name selected: ',file_name)
            print('\n--- Select From List of files ---\n')
           
            for i in range(0,len(files))  :  
                print(i, files[i])    

            file_str = input('\nEnter to accept file selected or a number:')

            if file_str == '' : #return file name selected
               file_info[0] = current_cwd
               file_info[1] = file_name
               os.chdir(reset_cwd) #reset current working directory 
               return file_info 

                          
            if int(file_str) == len(files)-1 : #this is the last entry which is create a new file
               file_name = input('Enter a new file name: ')   
               temp = open(file_name,'w')#create it
               temp.write('New file') 
               temp.close()    

            else :
               print('Number:',int(file_str))
               file_name = files[int(file_str)] 
            
 

    except Exception as Err:
        print('Error in select_file()')
        print(Err)

def search_file(frag_name,frag_dir,cipher_name,cipher_dir,OTP_name,OTP_dir,start_point):

    try:
            
        frag_path = frag_dir + '/' + frag_name
        frag_size = os.path.getsize(frag_path)

        print('Fragment:',frag_name,'Fragment Size:',frag_size,'\n')

        cipher_path = cipher_dir +'/'+ cipher_name  #where to find the cipher file

        cipher_size = os.path.getsize(cipher_path) #how big is the cipher file?

        print('Cipher File:',cipher_path,'\nCipher Size:', format(cipher_size,','),'\n')
    
        OTP_path = OTP_dir +'/'+ OTP_name #where to find the OTP file

        OTP_size = os.path.getsize(OTP_path)

        print('\nOTP:',OTP_path,'\nOTP Size:',format(OTP_size,','))
                
        frag_file = open(frag_path,'rb')         #Open fragment for reading bytes
        OTP_file  = open(OTP_path,'rb')          #Open OTP for reading bytes
        cipher_file = open(cipher_path,'rb')     #Open cipher for reading bytes

        cipher_ints = [0] * cipher_size          #create list to hold cipher bytes
        OTP_ints = [0] * OTP_size                #create a list to hold OTP bytes
        XOR_ints = [0] * frag_size               #create a short list of to hold enciphered bytes known to be in the message
        fragment_ints=[0] * frag_size            #create a list to hold bytes from the fragment text

        print('\nBusy reading in the OTP. This might take a minute.\n')
    
        for i in range(0,OTP_size):             #read in all of the OTP bytes and convert them to integers
            OTP_byte = OTP_file.read(1)         #read in an OTP byte                       
            OTP_ints[i] = int.from_bytes(OTP_byte, byteorder='big') #convert it to an integer and save it in the list

        OTP_file.close()

        print('Busy Reading in the cipher file. This might take a minute.\n')

        for i in range(0,cipher_size) :         #read in all of the cipher bytes and convert to integers
            cipher_byte = cipher_file.read(1)   #read in a cipher byte
            cipher_ints[i] = int.from_bytes(cipher_byte, byteorder='big') #convert to integer and save it in the list

        cipher_file.close()

        out_str='' #a string to hold the fragment bytes.

        for i in range(0,20) :                #read first 20 bytes of the fragment
            fragment_byte  = frag_file.read(1)
            fragment_ints[i]  = int.from_bytes(fragment_byte, byteorder='big') #convert it to integer and save in the list
            out_str = out_str+chr(fragment_ints[i])

        frag_file.close()
        
        print('\nThis is the fragment:',out_str)        #just to verify what we are using as the fragment. 
        print('These may not be printable characters')
        input('Paused. Hit enter to continue.')
        
        print('\nSearching for encipher match. This will take a while!')

        print('\nProgress is shown in 100 increment steps of the trial OTP position')

        iters = 0 #Count the iterations. An iteration is enciphering the fragment starting at a given position
                  #in the OTP and then comparing it with the enciphered bytes in the cipher file
                  #looking for a match. If a match is found then we know where the fragment starts
                  #in the original clear text file. Call this F. The cipher key starts F bytes before the
                  #value of the trial position in the OTP
        
        elapsed_time_start = time.process_time()
        
        print('Start\t\t',format(elapsed_time_start,'0.4'),'\tsecs')

        #The starting_point is passed in through the parameter list
      
        for trial_cipher_key in range(start_point,OTP_size) : #Potentially we will have to try every cipher key

            if trial_cipher_key%100 == 0: #print progress as we go along.
               
               elapsed_time_stop = time.process_time()
               
               time_difference = elapsed_time_stop - elapsed_time_start
               
               print('Elapsed Time:\t\t',format(time_difference,'0.4'),'\tsecs')

               print('\nTrial OTP Position:',trial_cipher_key) #progress indicator
               if time_difference != 0 :
                  iterations_per_sec = iters/time_difference
                  print('Iterations per second:',format(iterations_per_sec,'0.4'))
           #Here is where we do a trial encipher of the fragment text using current cipher key value
            
            for i in range(0,20) : #encipher these 20 bytes of the fragment text starting at the current trial_cipher_key position of the OTP
                XOR_ints[i] =  fragment_ints[i] ^ OTP_ints[i+trial_cipher_key] #encrypt next byte of the fragment using next byte of the OTP
                #and save these encrypted values in a list
            
                #Do these 20 XOR_ints match a sequence of 20 bytes of the cipher_ints?
                #If so we know where the fragment starts in the clear text.
                #If there are no matches ten we move one byte further down the OTP. 
                    
            cipher_pos = 0 #start at beginning of cipher file every time
            iters = iters +1 #lets count the number of trials we have to make.
             
            for i in range(0,cipher_size-20) : #Potentially we have to scan the entire cipher file
                                               #looking for a match
              
                

                match = True #assume we get a match at the current position of the cipher file

                for j in range(0,20) : #compare this set of 20 XOR integers with the encrypted values starting at posiiton cipher_pos
                   if XOR_ints[j] != cipher_ints[j+cipher_pos]: #cipher_position is where we are in the cipher integer list
                      match = False #if they don't match we advance one byte further down the cipher file list and compare again

                #after this comparison if even one pair did not match we need to move one byte down the cipher list.

                if not match :
                   cipher_pos = cipher_pos +1 #We advance one position down the cipher ints list and try again
                    
                else: #if we make it to here then there was a match starting at cipher postion. 
                    elapsed_time_stop = time.process_time()
                    #elapsed_time_stop = elapsed_time_stop *1000
                    time_difference = elapsed_time_stop - elapsed_time_start
                 
                    print('Trial comparisons: ',format(iters,','))    
                    print('\nFragment match in cipher file found at position',cipher_pos,'\tusing ',trial_cipher_key, ' in OTP:')
                    print('\nCipher key is computed as:',trial_cipher_key-cipher_pos)
                    
                    print('Elapsed Time:\t\t',format(time_difference,'0.4'),'\tsec')

                    if time_difference != 0 :
                       iterations_per_sec = iters/time_difference
                       print('Iterations per second:',format(iterations_per_sec,'0.4'))
                                  

                    return(trial_cipher_key-cipher_pos)


    except Exception as Err :
        print(Err)
        return 'error in search_file()'

def get_trial_cipher_key(OTP_size):
    try:
        print('\n--------------------------- Get Cipher Key -------------------------------')
        print('\nThe cipher key is the starting trial point in the OTP file')
        print('The cipher key must be in the range 0 to ', format(OTP_size,','))

        entry = False

        while not entry:
            cipher_str = input('\nEnter Cypher Key (Default = 0):')
            if cipher_str == '':
               trial_cipher_key = 0
               entry = True
            else :
               trial_cipher_key = int(cipher_str)
               if trial_cipher_key < 0 or trial_cipher_key >OTP_size:
                  print('Error: the cipher key must be in the range 0 to ', format(OTP_size,','))
               else:
                  entry = True     

        if entry== True :
            return trial_cipher_key
   

    except Exception as Err :
       print(Err)
       return 'Error in get_trial_cipher_key()'

 

def main() :
    try:

        frag_name = 'none'
        frag_dir = 'none'
        cipher_name = 'none'
        cipher_dir = 'none'
        OTP_name = 'none'
        OTP_dir = 'none'
        start_point=0
        settings_file='hack-settings.txt'
        
        command       = 0

        while command != 9 :

          command = menu(frag_name,frag_dir,cipher_name,cipher_dir,OTP_name,OTP_dir,start_point,settings_file)

          if command == 1 :
             print('\nGet Fragment Filename. Default(frag.txt)')
             return_info = select_file(frag_dir)
             if return_info[1] =='none':
                frag_name ='frag.txt'
                frag_dir  = os.getcwd() 
             else :
                frag_name = return_info[1]
                frag_dir =return_info[0] 
               
          if command == 2 :
              print('\nGet Cipher Filename. Default: (cipher.bin)')
              return_info = select_file(cipher_dir) 
              if return_info[1] =='none':
                cipher_name ='cipher.bin'
                cipher_dir  = os.getcwd() 
              else :
                cipher_name = return_info[1]
                cipher_dir =return_info[0] 

          if command == 3 :
             print('\nGet OTP Filename. Default: (OTP-2MB.bin)')
             return_info = select_file(OTP_dir) 
             if return_info[1] =='none':
                 OTP_name ='cipher.bin'
                 OTP_dir  = os.getcwd() 
             else :
                OTP_name = return_info[1]
                OTP_dir =return_info[0]
                
          if command == 4: #Note that the cipher key must be less than or equal to the OTP_size
              if OTP_name != 'none' :
                OTP_path = OTP_dir +'/'+ OTP_name
                OTP_size = os.path.getsize(OTP_path)
                start_point=get_trial_cipher_key(OTP_size)
                print(start_point)
              else:
                print('OTP file must be opened first to get length.')

          if command == 5 :
               result = search_file(frag_name,frag_dir,cipher_name, cipher_dir,OTP_name,OTP_dir,start_point)
               print('\nCipher Key Found:',result)
               
          if command == 6 :
                print('To hide values in settings file, use Command 8 to reset all values to default before saving')
                 #                        0         1          2           3              4      5   
                result = save_settings(frag_name, frag_dir, cipher_name, cipher_dir, OTP_name, OTP_dir,start_point,settings_file)
                settings_file=result
                print('\nResult:',result) 

          if command == 7 :
                rv = load_settings(settings_file)

                if rv == 'none':
                    print('\nSettings file not found, save settings first. ')

                else:
                          
                    #note that we need to slice off the '\n' from each string read
                    frag_name       = rv[0] 
                    frag_name       = frag_name[0:len(frag_name)-1]
                    frag_dir        = rv[1]
                    frag_dir        = frag_dir[0:len(frag_dir)-1]
                    cipher_name     = rv[2]
                    cipher_name     = cipher_name[0:len(cipher_name)-1]
                    cipher_dir      = rv[3]
                    cipher_dir      = cipher_dir[0:len(cipher_dir)-1]
                    OTP_name        = rv[4]
                    OTP_name        = OTP_name[0:len(OTP_name)-1] 
                    OTP_dir         = rv[5]
                    OTP_dir         = OTP_dir[0:len(OTP_dir)-1] 
                    start_point     = rv[6]
                    start_point     = int(start_point)
                    settings_file   = rv[7]
                    print('Saved settings loaded')               

          if command == 8:
                frag_name = 'none'
                frag_dir  = 'none'
                cipher_name = 'none'
                cipher_dir = 'none'  
                OTP_name = 'none'
                OTP_dir = 'none'
                start_point=0
                current_cws='none'
                
          if command == 9:
               pause =input("Paused: if you wish to save settings enter 's', othewise hit enter to exit program: ") 
               if pause == 's' :
                  result = result = save_settings(frag_name, frag_dir, cipher_name, cipher_dir, OTP_name, OTP_dir,start_point)
                  print('\nResult:',result)
               return('Program Ended Normally')
                
    except Exception as Err :
           print(Err)
           return 'error in function main()'

#call main

result = main()
print(result)

          
