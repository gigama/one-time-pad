#William Marcy
#Using random binary files for enciphering and deciphering computer files
#This utility enciphers an arbitrary file byte by byte using a binary One Time Pad (OTP file) and a cipher key

import os #lets us use operating system specific functions such as getting file size

version = '10-20-2023'


print('Author: William Marcy, PhD, PE')
print('Revised by:----------------')
print('Date of Last Revision:10/20/2023')
print('This is Public Domain Software')

print('Version:',version,'\n')

print('This utility implements the One Time Pad encipher and decipher algorithm.\n')

print('The reason I use a text menu rather than a graphical user interface is to ensure that this utility')
print('will run equality well on Windows, Mac and Unix (Ubuntu) operating systems.')
print('Graphical user interfaces are operating system dependent\n')

print('This utility XORs bytes sequentially from any arbitrary file with bytes from a random')
print('number One Time Pad (OTP) file using a cipher key. The OTP is treated as a circular list. The')
print('cipher key is the starting point in the circular OTP. The cipher key can be any number between 0 and')
print('the length of the OTP -1 (Note: we start counting positions at 0). If the OTP consists of 1 GB of random')
print('numbers then the cipher key can be any number between 0 and 999,999,999. Without the cipher key')
print('deciphering files is extremely difficult even if the OTP is compromised. The resulting XOR bytes')
print('are saved in a user designated file and directory.\n')

print('Commands  7 and 8 in the menu perform completely reversible XOR operations\n')
print(' Note that in Python ^ is the XOR operator\n')

print('If the file receiving the bytes from A^OTP is designated as B, B^OTP recovers the bytes corresponding')
print('to A. B is the encryption of A using the OTP.\n')

print('This utility allows saving XOR results by choosing a file name and directory other than those of the original files.')
print('This protects valuable source files and enciphered files from being overwritten if a mistake')
print('is made in the choice of OTP and cypher key used.')

print('\nIf two or more parties have the same OTP file and know the pass phrase or cipher key then they can exchange')
print('unbreakable enciphered files')

# In then event that your computer is seized you do not want to have settings files contain the names of the OTP files, 
# the cipher key or the pass phrase. Before saving settings use command 11 to reset all of the values to none

def menu(A_name, A_dir, A_XOR_OTP, A_XOR_OTP_dir, B_name, B_dir, B_XOR_OTP, B_XOR_OTP_dir, OTP_name, OTP_dir, OTP_size, Plt_size,Ecr_size,cipher_key,cipher_phrase,settings_file) :

    try:
        print('\n   ------------ Command Menu -------------\n')
        print('1   - Choose a file to encipher  (A)')
        print('          - File:',A_name)
        print('          - Dir:',A_dir)
        print('          - Size:',format(Plt_size,','))

        print('2   - Choose a file to receive the enciphered file (B)')
        print('          - File:',A_XOR_OTP)
        print('          - Dir:',A_XOR_OTP_dir)

        print('3   - Choose a file to decipher  (B)')
        print('          - File:',B_name )     
        print('          - Dir:',B_dir)
        print('          - Size:',format(Ecr_size,','))

        print('4   - Choose a file to receive the deciphered file (A)')
        print('          - File:',B_XOR_OTP)
        print('          - Dir:',B_XOR_OTP_dir)

        
        print('5   - Choose a file to use as one time pad ')
        print('          -OTP File:',OTP_name)
        print('          -OTP Dir:',OTP_dir)
        print('          -Size:',format(OTP_size,','))
       
        print('6   - Enter a pass phrase phrase to generate a cipher key:')
        print('          - Current pass phrase:',cipher_phrase)
        print('          - Current cipher key:',cipher_key)
        print('7   - Encipher File: A ^ OTP -->',A_XOR_OTP)
        print('8   - Decipher File: B ^ OTP -->',B_XOR_OTP)
        print('9   - Save current file, directory and parameter settings to -->',settings_file)
        print('10 - Load saved file, directory and parameter settings from <--',settings_file)
        print('11 - Reset parameters to none')
        print('12 - Exit program')

        command_str = input('\nEnter a command number: ')

        if command_str != '':
            command = int(command_str)
            while command < 1 or command >12 :
                print('Number must be 1 to 12')
                command = int(input('Please re-enter number: '))
        else :
            print('Default is 1')
            command = 1

        return command


    except Exception as Err :
        print('Error in Operations menu()')
        print(Err)

def select_directory() : #returns path & name of the directory selected

    try:

        select_dir = True #gets the while loop started

        new_cwd = 'none' #no directory selected yet

        starting_dir = os.getcwd() #save the current working directory when we enter this function

        while select_dir :

            explore_dir = True   #gets the while loop below started

            #------------------------ begin exploring directories --------------------
            
            while explore_dir: 

                current_cwd = os.getcwd() #save current working directory. This may change
                                          #while this function is used.
                
                print('\nCurrent CWD: ',current_cwd)  #just so we know where we are now


                dirs  = [] #list will hold names of sub directories in the CWD, if any
               
                for (dirpath, dirnames, filenames) in os.walk(current_cwd):
                    dirs.extend(dirnames)   #save the sub directory names
                    break                   #we don't need to walk the whole tree
                
                dirs.append("Use Current Working Directory")
                dirs.append('Create A New Sub Directory')

                print('\n--- List of Sub Directories---\n')
            
                for j in range(0,len(dirs))  :  
                    print(j, dirs[j])    
               
                dir_str = input("\nEnter to accept current value,'u' to move up a level,'x' to exit operation or number to select: ")
                            
                if dir_str =='' : #we are all finished
                      os.chdir(starting_dir) #reset to the starting directory  
                      return new_cwd          
                                
                if dir_str == 'u' :
                       os.chdir('../') #move up a directory level 
                       break
                    
##                if dir_str == 'r':
##                       os.chdir('/') #move to root directory
##                       break
                    
                if dir_str == 'x' : #exiting current operation
                    
                      os.chdir(starting_dir) #reset to the starting directory  
                      return 'none'     


                dir_no = int(dir_str) #we get here if a number was entered.

                if dirs[dir_no] == 'Use Current Working Directory':
                    return 'none'

                if dir_no == len(dirs) - 1 :#Create a new directory
                    dir_name = input('Enter a new sub directory name')
                    dir_path = current_cwd + '/' + dir_name
                    os.mkdir(dir_path)

                else:
                    new_cwd = current_cwd + '/' + dirs[dir_no]
                    os.chdir(new_cwd) #move to the new directory

    except Exception as Err:
        print('Error in select_directory()')
        print(Err)

def select_file(Passed_CWD) : #select a file from the passed current working directory

    try:

        reset_cwd= os.getcwd() #save the current working directory

        #print('Passed CWD',Passed_CWD)
                    
        if Passed_CWD == 'none':
           start_cwd = os.getcwd() #save the current working directory
        else:
           start_cwd = Passed_CWD #use the CWD passed in
        
        print('\nCurrently using:',start_cwd) #so we know what directory is being used
      
        pause = input("\nEnter to accept the current value or 'c' to change CWD: ")

        if pause == 'c':

           start_cwd = select_directory() #find a new directory
                       
           if start_cwd == 'none':   # No directory selection was made so continue with the one passed in
              start_cwd = Passed_CWD
           if start_cwd =='none': # if the one passed in was 'none' use the current working directory
              start_cwd = os.getcwd() 
           
        os.chdir(start_cwd) #change to the selected directory
                        
        #print('start_cwd',start_cwd)
        
        current_cwd = os.getcwd() #save current working directory

        print('\nCurrently using CWD: ',current_cwd)

        #input('pause')
              
        file_select = True

        file_name = 'none'

        files = [] #list will hold file names of current directory
        file_info = [0]*2 #return information
        
        for (dirpath, dirnames, filenames) in os.walk(current_cwd):
            files.extend(filenames) #save the file names
            break

        files.append('Create A New File') 
        
        #pause=input('paused')
        
        while file_select :
            print('\nCurrent file name selected: ',file_name)
            print('\n--- Select From List of files ---\n')
           
            for i in range(0,len(files))  :  
                print(i, files[i])    

            file_str = input("\nEnter to accept current file selected, 'x' to exit operation or a number:")

            if file_str == '' : #return file name selected
               file_info[0] = current_cwd
               file_info[1] = file_name
               os.chdir(reset_cwd) #reset current working directory 
               return file_info 

            if file_str=='x': #exiting operation
               file_info[0] = current_cwd
               file_info[1] = 'none'
               os.chdir(reset_cwd) #reset current working directory 
               return file_info 


            if int(file_str) == len(files)-1 : #this is the last entry which is create a new file
               file_name = input('Enter a new file name: ')   
               temp = open(file_name,'w')#create it
               temp.write('New file') 
               temp.close()    



            else :
               print('Number:',int(file_str))
               file_name = files[int(file_str)] 
            
 

    except Exception as Err:
        print('Error in select_file()')
        print(Err)

def save_settings(A_name, A_dir, A_XOR_OTP, A_XOR_OTP_dir, B_name, B_dir, B_XOR_OTP, B_XOR_OTP_dir, OTP_name, OTP_dir, OTP_size, Plt_size,Ecr_size,cipher_key,cipher_phrase,settings_file) :
#                                 0            1              2                         3                       4           5              6                       7                         8                  9             10             11         12               13              14                 15
    try:

        current_cwd = os.getcwd() #get the current working directory
        #print('Current Working Directory:',current_cwd)
        print('Current Settings File:',settings_file)
        
        settings_file_name = input('Enter a different name for the settings file or enter to accept: ')

                
        if settings_file_name =='':
           settings_file_name = settings_file
       
        settings=settings_file_name

        settings = open(settings,'w')       
        settings.write(A_name +'\n')        #0
        settings.write(A_dir+'\n')          #1
        settings.write(A_XOR_OTP +'\n')     #2
        settings.write(A_XOR_OTP_dir +'\n') #3
        settings.write(B_name  +'\n')       #4    
        settings.write(B_dir +'\n')         #5
        settings.write(B_XOR_OTP  +'\n')    #6
        settings.write(B_XOR_OTP_dir  +'\n')#7
        settings.write(OTP_name+'\n')       #8    
        settings.write(OTP_dir+'\n')        #9
        settings.write(str(OTP_size)+ '\n') #10
        settings.write(str(Plt_size)+'\n') #11
        settings.write(str(Ecr_size)+'\n')#12
        settings.write(cipher_phrase+'\n')#13
        settings.write(str(cipher_key)+'\n')#14    
        
        settings.write(str(settings_file_name)+'\n')#15
              
        settings.write('\nThe following path string is your current working directory location.\n\n')

        if A_dir == 'none':
           settings.write('none\n\n')
        else:
           settings.write(current_cwd+'\\'+'\n\n')    #This is an aid to editing settings files

        settings.write('Use a text editor such as Notepad to edit directory strings\n')
        settings.write('following a relocation of the encipher host directory as needed.\n')
        settings.close()

        return settings_file_name

    except Exception as Err :
         print('Error in function save_settings()')
         print(Err)

def load_settings(settings_file) :

    try:

       print('Current Settings File:',settings_file)
        
       settings_file_name = input('Enter a different name for the settings file or enter to accept: ')
        
       if settings_file_name =='':
          settings_file_name = settings_file

            
       settings=settings_file_name
        
       settings = open(settings,'r')

       rv = [0]*16 #setup return array of values read from file
        
       rv[0] = settings.readline() #0 A_name
        
       rv[1] = settings.readline() #1 A_dir
           
       rv[2] = settings.readline() #2 A_XOR_OTP
   
       rv[3] = settings.readline() #3 A_XOR_OTP_dir
           
       rv[4] = settings.readline() #4 B_name
    
       rv[5] = settings.readline() #5 B_dir
           
       rv[6] = settings.readline() #6 B_XOR_OTP
           
       rv[7] = settings.readline() #7 B_XOR_OTP_dir
          
       rv[8] = settings.readline() #8 OTP_name
      
       rv[9] = settings.readline() #9 OTP_dir
         
       rv[10] = settings.readline() #10 OTP_size
        
       rv[11] = settings.readline() #11 Plt_size
        
       rv[12] = settings.readline() #12 Ecr_size
       
       rv[13]= settings.readline() #13 pass phrase

       rv[14] = settings.readline() #14 cipher_key
     
       rv[15] = settings_file_name #15 update settings file name
          
       settings.close()
       
  #These are used for debugging purposes       
##       print('Values read from settings file')
##       print('rv[0]:',rv[0])
##       print('rv[1]:',rv[1])
##       print('rv[2]:',rv[2])
##       print('rv[3]:',rv[3])
##       print('rv[4]:',rv[4])
##       print('rv[5]:',rv[5])
##       print('rv[6]:',rv[6])
##       print('rv[7]:',rv[7])
##       print('rv[8]:',rv[8])
##       print('rv[9]:',rv[9])
##       print('rv[10]:',rv[10])
##       print('rv[11]:',rv[11])
##       print('rv[12]:',rv[12])
##       print('rv[13]:',rv[13])
##       print('rv[14]:',rv[14])
##       print('rv[15]:',rv[15])
##                
##       temp_stop=input('Enter to continue')
       
       return rv
    
    except Exception as Err:
        print(Err)
        print('Error in function load_settings()')
        return 'none'

def main():

    try:
      
      A_name ='none'
      A_dir = 'none'
      B_name = 'none'
      B_dir = 'none'  
      A_XOR_OTP = 'none'
      A_XOR_OTP_dir = 'none'
      B_XOR_OTP = 'none'
      B_XOR_OTP_dir = 'none'
      OTP_name = 'none'
      OTP_dir = 'none'
      OTP_size = 0
      Plt_size = 0
      Ecr_size = 0
      cipher_key = 0
      cipher_phrase='none'
      settings_file = 'settings.txt'
             
      command       = 0
      
      while command != 12 :
          
          command = menu(A_name,A_dir,A_XOR_OTP,A_XOR_OTP_dir,B_name,B_dir,B_XOR_OTP,B_XOR_OTP_dir,OTP_name,OTP_dir,OTP_size,Plt_size,Ecr_size,cipher_key,cipher_phrase, settings_file)

          if command == 1 :
             print('\nGet source file A)')
             return_info = select_file(A_dir)
             if return_info[1] =='none':
                A_name ='none'
                A_dir  = 'none'
                Plt_size = 0
             else :
                A_name = return_info[1]
                A_dir =return_info[0]
                Plt_size = os.path.getsize(return_info[0] + '/' + return_info[1])
               
          if command == 2 :
              print('\nGet A ^ OTP destination')
              return_info = select_file(B_dir) 
              if return_info[1] =='none':
                  for i in range(0,len(A_name)) :
                      if A_name[i] == '.' :
                         A_XOR_OTP = A_name[0:i] +'.bin' 
                         A_XOR_OTP_dir = return_info[0]
                         break
             
              else :
                  A_XOR_OTP = return_info[1]
                  A_XOR_OTP_dir = return_info[0] 


          if command == 3 :
             Ecr_size = 0 
             print('\nGet source file B. Default(B_source.bin)')
             return_info = select_file(A_XOR_OTP_dir)
             if return_info[1] =='none':
                B_name ='none'
                B_dir  = 'none'
                Ecr_size = 0
             else :
                B_name = return_info[1]
                B_dir =return_info[0]
                Ecr_size = os.path.getsize(return_info[0] + '/' + return_info[1])

          if command == 4 :
              print('\nGet B ^ OTP destination. Default(B_source.txt)')
              return_info = select_file(B_XOR_OTP_dir) 
              if return_info[1] =='none':
                 B_XOR_OTP = 'none' 
                 B_XOR_OTP_dir  = 'none'
              else :
                 B_XOR_OTP = return_info[1]
                 B_XOR_OTP_dir =  return_info[0] 

              
          if command == 5 : 
               print('\nGet file name of the OTP. Default (OTP-2MB.bin)') 
               return_info = select_file(OTP_dir) 

               if return_info[1] == 'none' :
                   OTP_name = 'none'
                   OTP_size=0
                   OTP_dir = 'none' 
               else:
                   OTP_name = return_info[1]
                   OTP_dir  = return_info[0] 
                   OTP_size = os.path.getsize(return_info[0] + '/' + return_info[1])

                              
          if command == 6 :

             temp_key = ''
            
             print('The cipher key must be in the range 0 to',OTP_size-1)
             
             while temp_key=='':
                  temp_key=input('Enter cipher key directly otherwise enter 0:')

             cipher_key = int(temp_key)

             if cipher_key !=0:
                cipher_phrase = 'none'
                if cipher_key > OTP_size-1:
                   print('cipher key ',cipher_key,' exceeds OTP size',OTP_size -1) 
                   print('Choose a smaller cipher key or a larger OTP')
                         
             if cipher_key == 0:
                cipher_phrase = input('Input pass phrase:')
                cipher_key=get_cipher_key(cipher_phrase,OTP_size)

             print('cipher phrase',cipher_phrase)
             print('cipher key:',cipher_key)


          if command == 7 : # A XOR OTP to encipher
               #print('\nCmd =:',command)
              if cipher_key < OTP_size:
                 result= file_XOR(A_name,A_dir,OTP_name,OTP_dir,A_XOR_OTP,A_XOR_OTP_dir,cipher_key,cipher_phrase,command)
                 print('\nResult:',result,'\n')
              else:
                 print('\ncipher_key > OTP size -1')
                 print('\nChoose a different cipher key or a larger OTP')      

          if command == 8: #B XOR OTP to decipher
               #print('\nCmd =:',command)
             if cipher_key < OTP_size:
               result= file_XOR(B_name,B_dir,OTP_name,OTP_dir,B_XOR_OTP,B_XOR_OTP_dir,cipher_key,cipher_phrase,command)
               print('\nResult:',result,'\n')
             else:
               print('\ncipher_key > OTP size -1')
               print('\nChoose a different cipher key or a larger OTP')
               
          if command == 9:
                print('To keep current values from being saved to the settings file, first use command 11 to reset defaults')
                result = save_settings(A_name, A_dir, A_XOR_OTP, A_XOR_OTP_dir, B_name, B_dir, B_XOR_OTP, B_XOR_OTP_dir, OTP_name, OTP_dir, OTP_size, Plt_size,Ecr_size,cipher_key,cipher_phrase,settings_file)

 #          Used for debugging               0            1              2                   3                          4            5            6                        7                         8                  9            10              11           12               13          14                  15
 #             print(cipher_phrase)
 #              temp_stop=input('cipher_phrase: temp stop in function 9')

                settings_file=result
                print('\nSaved to:',result)
           
          if command == 10:
                rv = load_settings(settings_file)
                if rv == 'none':
                    print('\nSettings file not found, save settings first. ')

                else:
                          
                    #note that we need to slice off the '\n' from each string read
                    A_name     = rv[0] 
                    A_name     = A_name[0:len(A_name)-1]
                    A_dir      = rv[1]
                    A_dir      = A_dir[0:len(A_dir)-1]
                    A_XOR_OTP  = rv[2]
                    A_XOR_OTP  = A_XOR_OTP[0:len(A_XOR_OTP)-1]
                    A_XOR_OTP_dir =rv[3]
                    A_XOR_OTP_dir  = A_XOR_OTP_dir[0:len(A_XOR_OTP_dir)-1]
                    B_name     = rv[4] 
                    B_name     = B_name[0:len(B_name)-1]
                    B_dir      = rv[5]
                    B_dir      = B_dir[0:len(B_dir)-1]
                    B_XOR_OTP  = rv[6]
                    B_XOR_OTP  = B_XOR_OTP[0:len(B_XOR_OTP)-1]
                    B_XOR_OTP_dir = rv[7]
                    B_XOR_OTP_dir  = B_XOR_OTP_dir[0:len(B_XOR_OTP_dir)-1]
                    OTP_name        = rv[8]
                    OTP_name        = OTP_name[0:len(OTP_name)-1] 
                    OTP_dir         = rv[9]
                    OTP_dir         = OTP_dir[0:len(OTP_dir)-1] 
                    OTP_size        = int(rv[10]) #convert to integer
                    Plt_size           = int(rv[11]) #convert to integer
                    Ecr_size          = int(rv[12]) # convert to integer
                    cipher_phrase =rv[13]
                    cipher_phrase=cipher_phrase[0:len(cipher_phrase)-1]
                 #   print('cipher_phrase:',cipher_phrase)
                    cipher_key      = int(rv[14]) #convert to integer
                         
                  #  temp_stop=input('temp stop in function 10')
                    
                    settings_file= rv[15] #update settings file name,

                    print('Saved settings loaded from:',settings_file)               
                
                
          if command == 11 : #reset to none
                A_name ='none'
                A_dir = 'none'
                B_name = 'none'
                B_dir = 'none'  
                A_XOR_OTP = 'none'
                A_XOR_OTP_dir = 'none'
                B_XOR_OTP = 'none'
                B_XOR_OTP_dir = 'none'
                OTP_name = 'none'
                OTP_dir = 'none'
                OTP_size = 0
                Plt_size = 0
                Ecr_size = 0
                cipher_key = 0
                cipher_phrase='none'
                print('Parameters set to none')
                settings_file = ('settings.txt')
               
    
                 

          if command == 12 :

               pause =input("Paused: If you wish to save settings enter 's', othewise hit enter to exit program: ") 

               if pause == 's' :

                  print('Current settings file:',settings_file)

                  new_settings_file_name = input('Enter new settings file name or hit enter to accept: ')

                  if new_settings_file_name != '': 
                     settings_file = new_settings_file_name
                    
                  result = save_settings(A_name, A_dir, A_XOR_OTP, A_XOR_OTP_dir, B_name, B_dir, B_XOR_OTP, B_XOR_OTP_dir, OTP_name, OTP_dir, OTP_size, Plt_size,Ecr_size,cipher_key,cipher_phrase,settings_file)

                  print('\nSettings saved to: ',result)

      return 'Program ended normally'

    except Exception as Err:
        print('Error in main()')
        print(Err)

def get_cipher_key(cipher_phrase,OTP_size):
    try:
        print('\n--------------------------- Get Cipher Key -------------------------------')
        print('\nThe cipher key is the starting point in the OTP file')
        
        total = 10

        for i in range (0,len(cipher_phrase)-1):
           total = total + ord(cipher_phrase[i])*300

#        temp = input('stop')

        cipher_key = int(total)
        
        if cipher_key > OTP_size:
           print('cipher_key generated:',cipher_key,'exceeds OTP Size',OTP_size)
           print('Please try a different pass phrase or choose a larger OTP')
           cipher_key = 0;
        return cipher_key
    
    except Exception as Err :
        print(Err)
        print('Error in get_cipher_key()')

   
#------------------------------------ XOR --------------------------------------


def file_XOR(source_name,source_dir,OTP_name,OTP_dir,XOR_name, XOR_dir,cipher_key,cipher_phrase,command):
    try:

        print('\nSource name: ',source_name)
        print('Source directory: ',source_dir)
        source_path = source_dir + '/' + source_name
        source_size = os.path.getsize(source_path)
        print('Source size: ',source_size)
        
        
        print('\nOTP name: ',OTP_name)
        print('OTP Directory: ',OTP_dir)
        OTP_path = OTP_dir + '/' + OTP_name
        OTP_size = os.path.getsize(OTP_path)
        print('OTP size: ',OTP_size)
        
        
        print('\nXOR Name: ',XOR_name)
        print('XOR Directory: ',XOR_dir)
        XOR_path = XOR_dir + '/' + XOR_name
       
        
        print('\nCipher key: ',cipher_key)
        print('\nPass Phrase',cipher_phrase)
        
        paused = input("\nPaused: If everything looks OK hit Enter or 'x' to exit: ")
        if paused == 'x':
            return 'User terminated function'

        #should be safe to open files
        
        source_file = open(source_path,'rb')
        OTP_file = open(OTP_path,'rb')
        XOR_file = open(XOR_path,'wb') 

        #skip over bytes in OTP equal to cipher_key

        n = 0 # keep count of OTP bytes skipped
        
        for i in range (0,cipher_key):
           OTP_byte = OTP_file.read(1) #skip over a byte
           n = n +1
        
        print('\nUsing ',OTP_name,' starting at :',n)

        print('\nBusy. This might take some time.')
        print('Progress is shown in decimal kilobytes')
           
        percent = 0
        progress = int(source_size /10)
        
        for i in range(0,source_size):
                        
           if i!=0 and i%progress == 0 :                        #keep track of progress
              percent = percent + 10
              kb = int(i/1000)             
              print(percent,'%',format(kb,','),'kb') 

           OTP_byte = OTP_file.read(1)                          #get next OTP byte
           OTP_int  = int.from_bytes(OTP_byte, byteorder='big') #convert to an integer

           n = n +1 #We just read another OTP byte, so count it

           #check for end of OTP file

           if n > OTP_size-1 : #we have reached end of the one time pad, so go back to beginnng
              print('\nReached end of one time pad, starting over at byte 0')
              OTP_file.close()                  #close the one time pad
              OTP_file = open(OTP_path,'rb')    #re-open the one time pad file
              n = 0                             #and start over at byte 0

           source_byte = source_file.read(1)       #read a byte from the source file
           source_int = int.from_bytes(source_byte, byteorder='big') #convert it to an integer    
               
           #XOR the two integers (this is the encipher step) 

           XOR_int = source_int ^ OTP_int #XOR source_int with the OTP_int to get destination int
           XOR_byte =(XOR_int).to_bytes(1,byteorder='big',signed = False) #convert XOR result to a byte
                                                                            #for writing to cipher file                           
           XOR_file.write(XOR_byte) #write out XOR byte to the XOR file

        #close all files
        OTP_file.close()
        XOR_file.close()
        source_file.close()
        
        return 'File XOR completed' 

    except Exception as Err:
        print(Err)
        print('Error in file_XOR()')


    
#call main()
result = main()
print(result)
