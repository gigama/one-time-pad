#William Marcy
#One Time Pad Segmentation Utility. This utility allows you to take a large one time pad binary file
#and copy segments of it to a new one time pad

version = '10-20-2023'
import os
print('\n')
print('Author: William Marcy, PhD, PE')
print('This is Public Domain Software')
print('Revised by:----------------')
print('Date of Last Revision:10/20/2023')

print('Version:',version,'\n')
print(' ----------------- One Time Pad Binary File Segment Utility -----------------------------\n')
print(' This utility will segment any existing file to produce a new OTP.                       \n')
print(' Many large files can be adapted for use as an OTP. Photo JPG files are typically many megabytes    ')      
print(' in size and can have a very high entropy. The compute-entropy program will allow you to   ')
print(' assess any file for potential use as a source of OTP random bytes. Entropy values greater')
print(' than 7.999 are perfectly adequate for use a OTP. A value of 8.00000 is perfect, but not    ')
print(' achievable in practice. The OTP files in these examples are often in the 7.9998+ range     ')
print(' The OTP-Random-File-Generator program produces very high entropy OTP files.              \n')

def main():

    end_of_pgm = False
    
    while not end_of_pgm :

        try:
            
            cwd = os.getcwd()
            print('-------- Select source file and directory --------')                       
        
            rv = select_file() #get source file and directory. rv is a list that is returned

            source_directory = rv[0]
            source_file = rv[1]

            print('Source File:',source_file)
            print('Source Directory:',source_directory)

            #input('Paused')

            if source_file == 'none':
               return('Program Terminated')

            source_path = source_directory + '/' + source_file

            print('\nSource Path:',source_path)

          
            OTP_length = os.path.getsize(source_path) #get the size of the random number file in bytes.
            print('\nOTP Length: ',format(OTP_length,','))
            
                  
            OTP_infile = open(source_path,'rb') #open for reading
         
            print('\nThe source file',source_file,'contains',format(OTP_length,','),'random integers in the range 0-255')
            print('You can select a range of values from this file to write a new binary one-time-pad file.')
            print('The segment must be in the range 0 to ',OTP_length - 1,'\n')
            
            max_length = OTP_length-1

            print('\nNote that in CS we start counting at zero.')
            print( 'Start value must be in range 0 to ',max_length)
            
            check_start_value = False
            
            while not check_start_value :

                start_value = int(input('Enter a starting position in the OTP source file: '))
 
                if start_value < 0 or start_value > max_length :
                   print('Start value entered',start_value,' is > ', max_length,' please re-enter')
                else:
                    check_start_value = True
                
   
            end_value = 0
                
            while end_value <= start_value :
                print('End position must be greater than ',start_value)
                end_value = input('Enter end position in the random number file: ')

                if end_value == '':
                   end_value = start_value+1
                   print('Default end position = start value +1',end_value)

                else :
                    end_value = int(end_value)
                    
                if end_value >= max_length :
                    print('Maximum end position is :',max_length)
                    end_value = max_length
                
            length = end_value-start_value+1

            print('New OTP length will be ', format(length,','))

            print('\n----------------- Now Select Output File ------------------.')
            
            
            rv1 = select_file() #rv1 is a list returning directory and file names

            output_file = rv1[1] #the output file name
          
            output_directory = rv1[0] #the output directory

            output_path = output_directory + '/' + output_file

            print('Output File: ',output_file)
            print('Output Directory: ',output_directory)
            print('Output Path: ',output_path)
            print('\nStart Value: ',format(start_value,','),'End Value: ',format(end_value,','))
            
            pause = input("Interval for progress report. Progress interval is multiplied by 1000:(default = 100) ")

            if pause == '' :
                divisor = 100000
            else :
                divisor = int(pause) * 1000    
                           
            pause =input("\nPaused: If everything looks OK hit 'enter' to write the new OTP or 'x' to exit program:")

            if pause == 'x' :
               return 'Program Terminated'
                                       
            #skip to start position in the input file

            n = 0    
            print('\nSkipping to starting position')
            print('Progress is in decimal bytes')
            print('This might take a while\n')

                      
            for i in range(0,start_value): #skipping to starting point in source OTP

                if i != 0 and i%divisor == 0 : #every 100k or 1000k bytes
                   print(format(i,','),'kb')
                   
                rand_byte = OTP_infile.read(1) #read one byte, but we don't do anything with it.
                n=n+1 #count it

            OTP_outfile  = open(output_path,'wb') #Open the output file in binary mode

            print('\nAt starting position')           
            print('\nNumber of random number bytes to be written :',format(length,','))
            print('Progress is in bytes')
            print('This might take a while\n')
           
            
            n = 0   #count number of bytes written to the new OTP file
                    #we are now at the starting position. Copy bytes from the
                    #starting position to the end position

            for i in range (start_value,end_value+1):

                if n != 0 and n%divisor == 0 : 
                   print(format(n,','))

                rand_byte = OTP_infile.read(1) #read a byte
                OTP_outfile.write(rand_byte)   #copy it to the outfile      
                n = n+1                        #count number of bytes written
            
            print('\n',format(n,','),' random number bytes were written to :',output_file)
            
            OTP_infile.close()   #close the open files
            OTP_outfile.close()

            #Check the new OTP binary file to see if it was segmented correctly

            OTP_length = os.path.getsize(output_path) #get the size of the new random number file in bytes.

            print('\nNew OTP length: ',format(OTP_length,','))

            OTP_infile = open(output_path,'rb')   #open the output file for reading

            pause = input("\nPaused: Enter number of values to read (default = 50):" )

            if pause == '' :
                no_to_read = 50
            else:
                no_to_read = int(pause)

            for i in range(0,no_to_read):
                rand_byte = OTP_infile.read(1) #read one random number byte
                rand_int = int.from_bytes(rand_byte, byteorder='big') #convert it to an integer
                print(i,rand_int)
                
            OTP_infile.close()
      

        except Exception as Err :
            print('error in main()')
            print(Err)

        paused = input("\nPaused: Hit enter to exit,'s' to segment another file: ")

        if paused == 's' :
            pass
        else:
            end_of_pgm = True
            return '\nProgram Ended normally'

def select_directory() : #returns path & name of the directory selected

    try:

        select_dir = True #gets the while loop started

        new_cwd = 'none' #no directory selected yet

        starting_dir = os.getcwd() #save the current working directory when we enter this function

        while select_dir :

            explore_dir = True   #gets the while loop below started

            #------------------------ begin exploring directories --------------------
            
            while explore_dir: 

                current_cwd = os.getcwd() #save current working directory. This may change
                                          #while this function is used.
                
                print('\nCWD: ',current_cwd)  #just so we know where we are now


                dirs  = [] #list will hold names of sub directories in the CWD, if any
               
                for (dirpath, dirnames, filenames) in os.walk(current_cwd):
                    dirs.extend(dirnames)   #save the sub directory names
                    break                              #we don't need to walk the whole tree

                if len(dirs) != 0:
                   dirs.append('Create new subdirectory for output') 
                   print('\n--- List of Sub Directories---\n')
                   for j in range(0,len(dirs))  :  
                        print(j, dirs[j])    
               
                dir_str = input("\nEnter to accept current,'u' to move up a level, 'x' to exit program, or number to select: ")
                            
                if dir_str =='' : #we are all finished
                   if new_cwd=='none':
                      print('No directory selected')
                      break
                   os.chdir(starting_dir) #reset to the starting directory  
                   return new_cwd          
                                
                if dir_str == 'u' :
                       os.chdir('../') #move up a directory level 
                       break  

#                  This should not be implemented since it will allow access to OS directories and files
##                if dir_str == 'r':
##                       os.chdir('/') #move to root directory
##                       break 

                if dir_str == 'x' :
                   os.chdir(starting_dir) #reset to the starting directory  
                   return 'none'    

                dir_no = int(dir_str) #we get here if a number was entered.
                
                if dir_no == len(dirs) - 1 :#Create a new directory
                    dir_name = input('Enter a new sub directory name:')
                    dir_path = current_cwd + '/' + dir_name
                    os.mkdir(dir_path)
                else:   
                   new_cwd = current_cwd + '/' + dirs[dir_no]
                   os.chdir(new_cwd) #move to the new directory

    except Exception as Err:
        print('Error in select_directory()')
        print(Err)

def select_file() : #select a file from the current working directory

    try:

        start_cwd = os.getcwd() #save current working directory
        
        print('\nCWD: ',start_cwd)
      
        pause = input("\nEnter to accept current CWD or'c' to change CWD: ")

        new_cwd = select_directory()

        if new_cwd != 'none':
             os.chdir(new_cwd) #change directories
        else:
             print('\nUsing current directory',start_cwd)  
          
        #input('Paused after operation select_directory()')

        current_cwd = os.getcwd() #remember current working directory

        file_select = True

        file_name = 'none'

        files = [] #list will hold file names of current directory
        file_info = [0]*2 #return information
        
        for (dirpath, dirnames, filenames) in os.walk(current_cwd):
            files.extend(filenames) #save the file names
            break
        
        files.append('Create file (only for segment output)')
        
        while file_select :
            print('\nCurrent file name selected: ',file_name)
            print('\n--- Select From List of files ---\n')
           
            for i in range(0,len(files))  :  
                print(i, files[i])    

            file_str = input("\nEnter to accept file selected, 'x' to exit operation or a number: ")

            if file_str == '' : #return file name selected
               file_info[0] = current_cwd
               file_info[1] = file_name
               os.chdir(start_cwd) #reset current working directory 
               return file_info 

            if file_str=='x':
               file_info[0] = current_cwd
               file_info[1] = 'none'
               os.chdir(start_cwd) #reset current working directory 
               return file_info

            if int(file_str) == len(files)-1 : #this is the last entry which is create a new file
               file_name = input('Enter a new file name--default: OTP-XB.bin:')   
               if file_name=='':
                  file_name='OTP-XB.bin' 

               temp = open(file_name,'w')#create it
               temp.write('New file') 
               temp.close()    

            else :
               file_name = files[int(file_str)] 
            
 

    except Exception as Err:
        print('Error in select_file()')
        print(Err)  
    

# call main()
result = main()
print(result)

      
