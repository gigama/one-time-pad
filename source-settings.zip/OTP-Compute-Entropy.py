#William Marcy
#Using random binary files for enciphering and deciphering computer files
#This program provides an example of computing entropy

import os #lets us use operating system specific functions such as getting file size
import math #we need this for the log base 2 computation of enytropy.
from os import listdir
from os.path import isfile

version = '10-20-2023'

print('\n')
print('Author: William Marcy, PhD, PE')
print('This is Public Domain Software')
print('Revised by:----------------')
print('Date of Last Revision:10/20/2023')


print('\n\nThis utility computes the entropy of a file of 8 bit bytes using sum (p*log2(p))for all values')
print('in the file. P is the probability that a given value occurs. Entropy is measured in bits. An 8 bit byte can store')
print('positive integers in the range 0-255. If all values in this range are equally likely to occur then the entropy')
print('will be exactly 8.00000. The average value will be exactly 127.5. The median (or middle value) will be 127.')
print('The median is the value for which 1/2 of the values in the file are less than this value and 1/2 of the values')
print('are greater than this value. The closer the entropy value is to 8.00000 the closer values are to being equally likely.\n')
print('\nVersion: ',version)

def select_directory() : #returns path & name of the directory selected

    try:

        select_dir = True #gets the while loop started

        new_cwd = 'none' #no directory selected yet

        starting_dir = os.getcwd() #save the current working directory when we enter this function

        while select_dir :

            explore_dir = True   #gets the while loop below started

            #------------------------ begin exploring directories --------------------
            
            while explore_dir: 

                current_cwd = os.getcwd() #save current working directory. This may change
                                          #while this function is used.
                
                print('\nCWD: ',current_cwd)  #just so we know where we are now
              
                dirs  = [] #list will hold names of sub directories in the CWD, if any
               
                for (dirpath, dirnames, filenames) in os.walk(current_cwd):
                    dirs.extend(dirnames)   #save the sub directory names
                    break                   #we don't need to walk the whole tree
                
                dirs.append('Use Current Working Directory')
                dirs.append('Create A New Sub Directory')

                print('\n--- List of Sub Directories---\n')
            
                for j in range(0,len(dirs))  :  
                    print(j, dirs[j])    
               
                dir_str = input("\nEnter to accept CWD,'u' to move up a level, 'x' to exit or number to select a directory: ")
                            
                if dir_str =='' : #we are all finished
                      os.chdir(starting_dir) #reset to the starting directory  
                      return new_cwd          
                                
                if dir_str == 'u' :
                       os.chdir('../') #move up a directory level 
                       break  

                if dir_str=='x':
                       return(current_cwd)

#               This should not be implemented since it will give access to OS files

##                if dir_str == 'r':
##                       os.chdir('/') #move to the root directory
##                       break 

                dir_no = int(dir_str) #we get here if a number was entered.

                if dirs[dir_no] == 'Use Current Working Directory':
                    return 'none'

                if dir_no == len(dirs) - 1 :#Create a new directory
                    dir_name = input('Enter a new sub directory name')
                    dir_path = current_cwd + '/' + dir_name
                    os.mkdir(dir_path)

                else:
                    new_cwd = current_cwd + '/' + dirs[dir_no]
                    os.chdir(new_cwd) #move to the new directory

    except Exception as Err:
        print('Error in select_directory()')
        print(Err)

def select_file() : #select a file from the current working directory

    try:

        start_cwd = os.getcwd() #save current working directory
        
        print('\nCWD: ',start_cwd)
      
        pause = input("\nEnter to accept current value of CWD or 'c' to change CWD: ")

        new_cwd = select_directory()

        if new_cwd != 'none':
            os.chdir(new_cwd) #change directories
          
        current_cwd = os.getcwd() #save current working directory

        file_select = True

        file_name = 'none'

        files = [] #list will hold file names of current directory
        file_info = [0]*2 #return information
        
        for (dirpath, dirnames, filenames) in os.walk(current_cwd):
            files.extend(filenames) #save the file names
            break

        files.append('Create A New File') 
        
        
        while file_select :
            print('\nCurrent file name selected: ',file_name)
            print('\n--- Select From List of files ---\n')
           
            for i in range(0,len(files))  :  
                print(i, files[i])    

            file_str = input("\nEnter to accept file selected, 'x' to exit or a number:")

            if file_str == '' : #return file name selected
               file_info[0] = current_cwd
               file_info[1] = file_name
               os.chdir(start_cwd) #reset current working directory 
               return file_info 

            if file_str ==  'x':
                file_info[0] = current_cwd
                file_info[1] = 'None Selected'
                os.chdir(start_cwd) #reset current working directory 
                return file_info 

              

            if int(file_str) == len(files)-1 : #this is the last entry which is create a new file
               file_name = input('Enter a new file name:')   
               temp = open(file_name,'w')#create it
               temp.write('New file') 
               temp.close()    

            else :
               file_name = files[int(file_str)] 
            
 

    except Exception as Err:
        print('Error in select_file()')
        print(Err)  
    
def main() :

    try:

        finished = False
        
        while not finished :
            
            rv = select_file() #changes current working directory

           
            file_name = rv[1] #file selected
            file_directory = rv[0]

            if file_name == 'None Selected':
                return('Program Terminated')

            file_path = file_directory + '/' + file_name
            file_size = os.path.getsize(file_path) 

            if file_size == 0:
               return 'File size was zero'

            file = open(file_path,'rb') #open the file for reading in binary

            print('Processing file. This could take a while.')
       
            count_value = [0] *256 #list to save the number of each value 0-255

            progress_value = int(file_size/10) #adjust depending on size of file

            sum_values = 0

            for i in range(0,file_size) :

                file_byte = file.read(1) #read a byte from the file
                file_value = int.from_bytes(file_byte, byteorder='big') #convert to an integer
                count_value[file_value] = count_value[file_value] + 1   #increase by 1 the value for that value                                                     
                sum_values = sum_values + file_value

                if i !=0 and i%progress_value ==0 :
                    print('Processed ',format(i,','),' bytes.')
                
            #print('\nFinished.')     

            check_sum = 0

            for n in range(0,256) : 
                check_sum = check_sum + count_value[n] #we verify that the counts add up to file size
                    
        #------------------ ready to compute frequency of occurance ------------------

            average = sum_values/file_size

            print('\nFile Size:',format(file_size,','),'Check Sum:',format(check_sum,','), 'These should be the same.')
            
             
            count_percent =[0] * 256 #create a list of percent of each value
                   
            for i in range(0,256):

                count_percent[i] = count_value[i]/file_size #the percent of the file that each value occurs


            entropy = 0
              
            for i in range(0,256): #compute entropy of each number in range (0-255)

               if count_percent[i] !=0 :
                  entropy = entropy + (count_percent[i] * math.log(count_percent[i],2))
                
            entropy = entropy * -1 #since these are log base 2 of numbers less than 1
                                   #the logs will be negative. We multiply by -1 to get a
                                   #positive number
  
            #find median

            median = 0 #add up values until half the file size is reached

            for i in range(0,255) :
                median = median + count_value[i] #how man values so far
                if median >= int(file_size/2) :  #then we have 1/2 the values
                   print('\nMedian Value :',i)   #remember the index as the median   
                   break
                   
            print('\nAverage Value: ',format(average,'.8f'))
            print('\nEntropy in bits: ',format(entropy,'.12f'),'\tMaximum Entropy is 8.0 bits for a file of 8 bit bytes.')     

            pause = input("Enter to exit or 'c' for another file.")

            if pause == '':
                return '\nProgram Ended Normally'


    except Exception as Err :
         print(Err)
         return '\nSomething went wrong in main()'



#call main()

result = main()

print(result)
      
